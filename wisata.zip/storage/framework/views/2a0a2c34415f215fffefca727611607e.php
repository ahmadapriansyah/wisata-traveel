

<?php $__env->startSection('title', 'Kelola Laporan'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Laporan Transaksi & Pemesanan</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">Rekap Laporan System</h3>
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kategori Laporan</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>Laporan Pemesanan Wisata</td>
                        <td><span class="badge badge-success">Siap</span></td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Laporan Pembayaran & Keuangan</td>
                        <td><span class="badge badge-success">Siap</span></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wisata\resources\views/laporan.blade.php ENDPATH**/ ?>