

<?php $__env->startSection('title', config('app.name', 'Laravel')); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Data Paket Wisata</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <a href="/paket-wisata/tambah" class="btn btn-warning">Tambah Paket</a>
    <table border="1px" class="table table-bordered mt-3" style="width:1000px;">
        <thead>
            <tr>
                <th>Nama Paket</th>
                <th>Destinasi</th>
                <th>Jenis Layanan</th>
                <th>Harga</th>
                <th>Durasi</th>
                <th>Meeting Point</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($datas->nama_paket); ?></td>
                <td><?php echo e($datas->destinasi); ?></td>
                <td><?php echo e($datas->jenis_layanan); ?></td>
                <td>Rp <?php echo e(number_format($datas->harga, 0, ',', '.')); ?></td>
                <td><?php echo e($datas->durasi_hari); ?> Hari</td>
                <td><?php echo e($datas->meeting_point); ?> (<?php echo e($datas->jam_kumpul); ?>)</td>
                <td>
                    <a href="/paket-wisata/ubah/<?php echo e($datas->id); ?>">Edit</a>
                    <?php echo method_field('delete'); ?>
                    <a href="/paket-wisata/hapus/<?php echo e($datas->id); ?>" onclick="return confirm('Anda Yakin Ingin Menghapus data ini ?')">Hapus</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wisata\resources\views/paket_wisata.blade.php ENDPATH**/ ?>