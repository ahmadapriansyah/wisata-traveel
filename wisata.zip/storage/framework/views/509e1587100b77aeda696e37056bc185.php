

<?php $__env->startSection('title', config('app.name', 'Laravel')); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Pengajuan Custom Trip</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <a href="/custom-trip/tambah" class="btn btn-warning">Tambah Pengajuan</a>
    <a href="/custom-trip/pdf" class="btn btn-secondary">Cetak PDF</a>
    <a href="/custom-trip/excel" class="btn btn-primary">Laporan Excel</a>
    <a href="/custom-trip/csv" class="btn btn-info">Laporan CSV</a>
    <table border="1px" class="table table-bordered mt-3" style="width:1000px;">
        <thead>
            <tr>
                <th>Tujuan</th>
                <th>Tanggal Diinginkan</th>
                <th>Durasi</th>
                <th>Jumlah Peserta</th>
                <th>Biaya Penawaran</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($datas->tujuan); ?></td>
                <td><?php echo e($datas->tanggal_diinginkan); ?></td>
                <td><?php echo e($datas->durasi_hari); ?> Hari</td>
                <td><?php echo e($datas->jumlah_peserta); ?> Orang</td>
                <td>Rp <?php echo e(number_format($datas->biaya_penawaran, 0, ',', '.')); ?></td>
                <td><?php echo e($datas->status); ?></td>
                <td>
                    <a href="/custom-trip/ubah/<?php echo e($datas->id); ?>">Edit</a>
                    <?php echo method_field('delete'); ?>
                    <a href="/custom-trip/hapus/<?php echo e($datas->id); ?>" onclick="return confirm('Anda Yakin Ingin Menghapus data ini ?')">Hapus</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wisata\resources\views/custom_trip.blade.php ENDPATH**/ ?>