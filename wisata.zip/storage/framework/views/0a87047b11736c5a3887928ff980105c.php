<?php
    // The search input needs an id, so the related label can target it.
    $searchInputId = $item['id'] ?? 'adminlte-sidebar-search-menu-input';

    // The menu that will be filtered by the AdminLTE SidebarSearch plugin.
    $searchTarget = '#'.($sidebarMenuId ?? 'adminlte-sidebar-menu');

    // The message to display when the filter matches no menu items.
    $searchEmptyText = $item['empty_text'] ?? __('adminlte::adminlte.no_matching_pages');
?>

<div class="sidebar-search" role="search">

    
    <label for="<?php echo e($searchInputId); ?>" class="visually-hidden"><?php echo e($item['text']); ?></label>

    <input class="form-control form-control-sm" type="search"
           id="<?php echo e($searchInputId); ?>"
           placeholder="<?php echo e($item['text']); ?>"
           aria-label="<?php echo e($item['text']); ?>"
           autocomplete="off"
           data-lte-toggle="sidebar-search"
           data-lte-target="<?php echo e($searchTarget); ?>"
           <?php echo $item['data-compiled'] ?? ''; ?>>

    
    <p class="fs-7 text-secondary mt-2 mb-0" data-lte-search-empty role="status" hidden>
        <?php echo e($searchEmptyText); ?>

    </p>

</div>
<?php /**PATH D:\wisata\vendor\jeroennoten\laravel-adminlte\src/../resources/views/partials/sidebar/menu-item-search-menu.blade.php ENDPATH**/ ?>