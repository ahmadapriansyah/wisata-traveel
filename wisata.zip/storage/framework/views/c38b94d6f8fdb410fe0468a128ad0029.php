

<?php $__env->startSection('title', 'Dashboard - Wisata Travel'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard Wisata Travel</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-3 col-6">
            <div class="small-box bg-info">
                <div class="inner">
                    <h3>10</h3>
                    <p>Modul Sistem</p>
                </div>
                <div class="icon">
                    <i class="fas fa-th-list"></i>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-6">
            <div class="small-box bg-success">
                <div class="inner">
                    <h3>Aktif</h3>
                    <p>Status Sistem</p>
                </div>
                <div class="icon">
                    <i class="fas fa-check-circle"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            Welcome to Wisata Travel & Tour Management System!
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wisata\resources\views/dashboard.blade.php ENDPATH**/ ?>