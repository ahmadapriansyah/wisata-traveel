

<?php $__env->startSection('title',config('app.name','Laravel')); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<body>
    <form action="/simpan">
        <?php echo csrf_field(); ?>
        <label>Nama</label>
        <input type="text" name="nama" class="form-control">
        <label>Alamat</label>
        <input type="text" name="alamat" class="form-control">
        <label>Jenis Kelamin</label>
        <select name="jenkel" class="form-control">
            <option value="L">Laki-laki</option>
            <option value="P">Perempuan</option>
        </select>
        <label>Kontak</label>
        <input type="text" name="kontak" class="form-control">
    </form>
    <input type="submit" value="Simpan" class="btn btn-secondary">
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\siakad\resources\views/tambah.blade.php ENDPATH**/ ?>