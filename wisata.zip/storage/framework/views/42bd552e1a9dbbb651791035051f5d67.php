

<?php ($searchId = $item['id'] ?? 'navbar-search-input'); ?>
<?php ($searchLabel = Lang::has('adminlte::adminlte.search') ? __('adminlte::adminlte.search') : 'Search'); ?>

<li class="nav-item d-none d-md-flex align-items-center">

    <form class="navbar-search ms-md-3" role="search" action="<?php echo e($item['href']); ?>"
          method="<?php echo e($item['method']); ?>">

        <?php if(strtolower($item['method']) === 'post'): ?>
            <?php echo e(csrf_field()); ?>

        <?php endif; ?>

        
        <label for="<?php echo e($searchId); ?>" class="visually-hidden">
            <?php echo e($item['text'] ?? $searchLabel); ?>

        </label>

        <div class="navbar-search-field">

            
            <input type="search" class="form-control" id="<?php echo e($searchId); ?>"
                   name="<?php echo e($item['input_name']); ?>"
                   placeholder="<?php echo e($item['text']); ?>"
                   aria-label="<?php echo e($item['text']); ?>"
                   autocomplete="off">

            
            <button class="navbar-search-submit" type="submit"
                    aria-label="<?php echo e($searchLabel); ?>">
                <i class="bi bi-search" aria-hidden="true"></i>
            </button>

        </div>

    </form>

</li>


<li class="nav-item d-md-none">
    <a class="nav-link" href="<?php echo e($item['href']); ?>" aria-label="<?php echo e($searchLabel); ?>">
        <i class="bi bi-search" aria-hidden="true"></i>
    </a>
</li>
<?php /**PATH D:\siakad\vendor\jeroennoten\laravel-adminlte\src/../resources/views/partials/navbar/menu-item-search-form.blade.php ENDPATH**/ ?>