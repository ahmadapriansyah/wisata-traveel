

<?php $__env->startSection('title', config('app.name', 'Laravel')); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Data Pengembalian (Refund / Pindah Jadwal)</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <a href="/pengembalian/tambah" class="btn btn-warning">Proses Pengembalian</a>
    <a href="/pengembalian/pdf" class="btn btn-secondary">Cetak PDF</a>
    <a href="/pengembalian/excel" class="btn btn-primary">Laporan Excel</a>
    <a href="/pengembalian/csv" class="btn btn-info">Laporan CSV</a>
    <table border="1px" class="table table-bordered mt-3" style="width:1000px;">
        <thead>
            <tr>
                <th>Jenis Penanganan</th>
                <th>Nominal Refund</th>
                <th>Alasan</th>
                <th>Tanggal Pengembalian</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($datas->jenis); ?></td>
                <td>Rp <?php echo e(number_format($datas->nominal, 0, ',', '.')); ?></td>
                <td><?php echo e($datas->alasan); ?></td>
                <td><?php echo e($datas->tanggal_pengembalian); ?></td>
                <td>
                    <a href="/pengembalian/ubah/<?php echo e($datas->id); ?>">Edit</a>
                    <?php echo method_field('delete'); ?>
                    <a href="/pengembalian/hapus/<?php echo e($datas->id); ?>" onclick="return confirm('Anda Yakin Ingin Menghapus data ini ?')">Hapus</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wisata\resources\views/pengembalian.blade.php ENDPATH**/ ?>