

<?php $__env->startSection('title',config('app.name','Laravel')); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <a href="/tambah" class="btn btn-warning">Tambah</a>
    <a href="/pdf" class="btn btn-secondary">Cetak PDF</a>
    <a href="/excel" class="btn btn-primary">Laporan Excel</a>
    <a href="/csv" class="btn btn-info">Laporan CSV</a>
    <table border="1px" class="table table-bordered" style="width:1000px;">
        <thead>
            <tr>
                <th>NISN</th>
                <th>Nama</th>
                <th>Alamat</th>
                <th>Jenis Kelamin</th>
                <th>Kontak</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($datas->nisn); ?></td>
                <td><?php echo e($datas->nama); ?></td>
                <td><?php echo e($datas->alamat); ?></td>
                <td><?php echo e($datas->jenkel); ?></td>
                <td><?php echo e($datas->kontak); ?></td>
                <td>
                    <a href="/siswa/ubah/<?php echo e($datas->nisn); ?>">Edit</a>
                    <?php echo method_field('delete'); ?>
                    <a href="/siswa/hapus/<?php echo e($datas->nisn); ?>" onclick="return confirm('Anda Yakin Ingin Menghapus data ini ?')">Hapus</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\siakad\resources\views/siswa.blade.php ENDPATH**/ ?>