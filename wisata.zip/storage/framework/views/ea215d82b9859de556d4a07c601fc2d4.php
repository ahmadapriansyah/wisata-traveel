

<?php $__env->startSection('title', config('app.name', 'Laravel')); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Data Pemesanan Wisata</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <a href="/pemesanan/tambah" class="btn btn-warning">Tambah Pemesanan</a>
    <a href="/pemesanan/pdf" class="btn btn-secondary">Cetak PDF</a>
    <a href="/pemesanan/excel" class="btn btn-primary">Laporan Excel</a>
    <a href="/pemesanan/csv" class="btn btn-info">Laporan CSV</a>
    <table border="1px" class="table table-bordered mt-3" style="width:1000px;">
        <thead>
            <tr>
                <th>Kode Pemesanan</th>
                <th>Jumlah Peserta</th>
                <th>Total Biaya</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
           <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($datas->kode_pemesanan ?? $datas->id ?? '-'); ?></td>
                <td><?php echo e($datas->jumlah_peserta ?? $datas->jumlah_pax ?? $datas->jumlah ?? '-'); ?> Orang</td>
                <td>Rp <?php echo e(number_format($datas->total_biaya ?? $datas->total_harga ?? $datas->harga ?? 0, 0, ',', '.')); ?></td>
                <td>
                    <span class="badge <?php echo e(($datas->status ?? '') === 'Lunas' ? 'badge-success' : 'badge-warning'); ?>">
                        <?php echo e($datas->status ?? 'Menunggu Pembayaran'); ?>

                    </span>
                </td>
                <td>
                    <a href="/pembayaran" class="btn btn-sm btn-primary">Bayar / Detail</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wisata\resources\views/pemesanan.blade.php ENDPATH**/ ?>