

<?php $__env->startSection('title', config('app.name', 'Laravel')); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Jadwal Keberangkatan</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <a href="/jadwal-keberangkatan/tambah" class="btn btn-warning">Tambah Jadwal</a>
    <a href="/jadwal-keberangkatan/pdf" class="btn btn-secondary">Cetak PDF</a>
    <a href="/jadwal-keberangkatan/excel" class="btn btn-primary">Laporan Excel</a>
    <a href="/jadwal-keberangkatan/csv" class="btn btn-info">Laporan CSV</a>
    <table border="1px" class="table table-bordered mt-3" style="width:1000px;">
        <thead>
            <tr>
                <th>Tanggal Berangkat</th>
                <th>Kuota</th>
                <th>Sisa Kuota</th>
                <th>Min. Peserta</th>
                <th>Biaya Operasional</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(isset($datas->tanggal_berangkat) ? date('d M Y', strtotime($datas->tanggal_berangkat)) : ($datas->tanggal ?? '-')); ?></td>
                <td><?php echo e($datas->kuota ?? 0); ?> Orang</td>
                <td><?php echo e($datas->sisa_kuota ?? $datas->kuota ?? 0); ?> Orang</td>
                <td><?php echo e($datas->min_peserta ?? $datas->minimal_peserta ?? '-'); ?></td>
                <td>Rp <?php echo e(number_format($datas->biaya_operasional ?? $datas->harga ?? 0, 0, ',', '.')); ?></td>
                <td>
                    <span class="badge <?php echo e(($datas->status_keberangkatan ?? '') === 'Terjadwal' ? 'badge-info' : 'badge-secondary'); ?>">
                        <?php echo e($datas->status_keberangkatan ?? $datas->status ?? 'Terjadwal'); ?>

                    </span>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wisata\resources\views/jadwal_keberangkatan.blade.php ENDPATH**/ ?>