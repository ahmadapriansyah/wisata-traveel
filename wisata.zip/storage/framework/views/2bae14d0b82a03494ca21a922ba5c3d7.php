

<?php $__env->startSection('title', 'Pembayaran'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Pembayaran & Verifikasi</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(Auth::user()->role === 'Wisatawan'): ?>
    <div class="card card-success">
        <div class="card-header">
            <h3 class="card-title">Form Konfirmasi Pembayaran</h3>
        </div>
        <form action="/proses-bayar" method="POST">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="form-group">
                    <label>ID Pemesanan</label>
                    <input type="number" name="id_pemesanan" class="form-control" placeholder="Masukkan ID Pemesanan" required>
                </div>
                <div class="form-group">
                    <label>Jumlah Bayar (Rp)</label>
                    <input type="number" name="jumlah_bayar" class="form-control" placeholder="Masukkan Nominal Pembayaran" required>
                </div>
                <div class="form-group">
                    <label>Bukti Pembayaran (Nama File / URL)</label>
                    <input type="text" name="bukti_bayar" class="form-control" placeholder="bukti_transfer.jpg" required>
                </div>
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-success">Kirim Pembayaran</button>
            </div>
        </form>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Daftar Pembayaran</h3>
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID Pembayaran</th>
                        <th>ID Pemesanan</th>
                        <th>Jumlah Bayar</th>
                        <th>Status</th>
                        <?php if(Auth::user()->role === 'Admin'): ?>
                        <th>Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($row->id ?? '-'); ?></td>
                        <td><?php echo e($row->id_pemesanan ?? $row->pemesanan_id ?? '-'); ?></td>
                        <td>Rp <?php echo e(number_format($row->jumlah_bayar ?? 0, 0, ',', '.')); ?></td>
                        <td><span class="badge badge-info"><?php echo e($row->status ?? 'Proses'); ?></span></td>
                        <?php if(Auth::user()->role === 'Admin'): ?>
                            <td>
                                <a href="/pembayaran/verifikasi/<?php echo e($row->id); ?>" class="btn btn-sm btn-success">Verifikasi</a>
                            </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wisata\resources\views/pembayaran.blade.php ENDPATH**/ ?>