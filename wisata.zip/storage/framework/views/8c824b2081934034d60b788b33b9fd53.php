

<?php $__env->startSection('title', 'E-Ticket / Voucher Wisata'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>E-Ticket / Voucher Wisata</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="card card-info">
        <div class="card-header">
            <h3 class="card-title">Daftar Tiket Wisata</h3>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>ID Tiket</th>
                        <th>ID Pemesanan</th>
                        <th>Kode Tiket</th>
                        <th>Tanggal Terbit</th>
                        <th>Status Tiket</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($datas->id ?? '-'); ?></td>
                        <td><?php echo e($datas->id_pemesanan ?? $datas->pemesanan_id ?? '-'); ?></td>
                        <td><strong><?php echo e($datas->kode_tiket ?? '-'); ?></strong></td>
                        <td><?php echo e(isset($datas->created_at) ? date('d M Y', strtotime($datas->created_at)) : '-'); ?></td>
                        <td><span class="badge badge-success">Aktif / Valid</span></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted">Belum ada tiket yang terbit.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wisata\resources\views/tiket.blade.php ENDPATH**/ ?>