

<?php $__env->startSection('title', config('app.name', 'Laravel')); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Ubah Password Akun</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="card card-warning card-outline">
                <div class="card-header">
                    <h3 class="card-title">Form Pembaruan Kata Sandi</h3>
                </div>
                <div class="card-body">
                    <form action="#" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Password Saat Ini</label>
                            <input type="password" name="password_lama" class="form-control" placeholder="Masukkan password lama..." required>
                        </div>
                        
                        <div class="form-group">
                            <label>Password Baru</label>
                            <input type="password" name="password_baru" class="form-control" placeholder="Masukkan password baru..." required>
                            <small class="form-text text-muted">Minimal 8 karakter, kombinasi huruf dan angka.</small>
                        </div>
                        
                        <div class="form-group">
                            <label>Konfirmasi Password Baru</label>
                            <input type="password" name="password_konfirmasi" class="form-control" placeholder="Ulangi password baru..." required>
                        </div>

                        <div class="mt-4">
                            <button type="submit" class="btn btn-warning">Perbarui Password</button>
                            <a href="/dashboard" class="btn btn-default float-right">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card card-info card-outline">
                <div class="card-header">
                    <h3 class="card-title">Petunjuk Keamanan Akun SIAKAD</h3>
                </div>
                <div class="card-body">
                    <ul>
                        <li>Gunakan kata sandi yang kuat dan tidak mudah ditebak oleh orang lain.</li>
                        <li>Hindari menggunakan tanggal lahir atau nama pribadi sebagai kata sandi.</li>
                        <li>Ubah kata sandi secara berkala minimal 3 bulan sekali untuk menjaga keamanan data akademis.</li>
                        <li>Jangan berikan akses password akun SIAKAD Anda kepada pihak manapun.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\siakad\resources\views/ubah_password.blade.php ENDPATH**/ ?>