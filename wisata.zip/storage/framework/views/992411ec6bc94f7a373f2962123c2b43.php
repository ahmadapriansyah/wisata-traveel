

<?php $__env->startSection('title', config('app.name', 'Laravel')); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Jadwal Mengajar</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Jadwal Mengajar Guru</h3>
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Hari</th>
                        <th>Jam</th>
                        <th>Mata Pelajaran</th>
                        <th>Kelas</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Senin</td>
                        <td>07:00 - 08:30</td>
                        <td>Matematika</td>
                        <td>X-IPA 1</td>
                    </tr>
                    <tr>
                        <td>Selasa</td>
                        <td>08:45 - 10:15</td>
                        <td>Bahasa Indonesia</td>
                        <td>XI-IPS 2</td>
                    </tr>
                    <tr>
                        <td>Rabu</td>
                        <td>10:30 - 12:00</td>
                        <td>Bahasa Inggris</td>
                        <td>XII-IPA 3</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\siakad\resources\views/jadwal.blade.php ENDPATH**/ ?>