<li <?php if(isset($item['id'])): ?> id="<?php echo e($item['id']); ?>" <?php endif; ?> class="nav-item <?php echo e($item['submenu_class']); ?>">

    
    <a class="nav-link <?php echo e($item['class']); ?> <?php if(isset($item['shift'])): ?> <?php echo e($item['shift']); ?> <?php endif; ?>"
       href="#" <?php echo $item['data-compiled'] ?? ''; ?>>

        <i class="nav-icon <?php echo e($item['icon'] ?? 'bi bi-circle'); ?> <?php echo e(isset($item['icon_color']) ? 'text-'.$item['icon_color'] : ''); ?>"></i>

        <p>
            <?php echo e($item['text']); ?>


            <?php if(isset($item['label'])): ?>
                <span class="nav-badge badge text-bg-<?php echo e($item['label_color'] ?? 'primary'); ?> me-3">
                    <?php echo e($item['label']); ?>

                </span>
            <?php endif; ?>

            <i class="nav-arrow bi bi-chevron-right"></i>
        </p>

    </a>

    
    <ul class="nav nav-treeview">
        <?php echo $__env->renderEach('adminlte::partials.sidebar.menu-item', $item['submenu'], 'item'); ?>
    </ul>

</li>
<?php /**PATH D:\siakad\vendor\jeroennoten\laravel-adminlte\src/../resources/views/partials/sidebar/menu-item-treeview-menu.blade.php ENDPATH**/ ?>