

<?php $__env->startSection('title', config('app.name', 'Laravel')); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Profil Pengguna</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-4">
            <div class="card card-primary card-outline">
                <div class="card-body box-profile text-center">
                    <img class="profile-user-img img-fluid img-circle" src="https://adminlte.io/themes/v3/dist/img/user2-160x160.jpg" alt="User profile picture">
                    <h3 class="profile-username text-center mt-2">Ahmad Subagja, S.Pd., M.Pd.</h3>
                    <p class="text-muted text-center">Guru Tenaga Pendidik / Admin SIAKAD</p>
                    
                    <ul class="list-group list-group-unbordered mb-3 text-left">
                        <li class="list-group-item">
                            <b>NIP / NIPY</b> <a class="float-right text-dark">198803152015031002</a>
                        </li>
                        <li class="list-group-item">
                            <b>Status</b> <a class="float-right text-success">PNS / Aktif</a>
                        </li>
                        <li class="list-group-item">
                            <b>Unit Kerja</b> <a class="float-right text-dark">SIAKAD Utama</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <h3 class="card-title">Detail Informasi Kepegawaian</h3>
                </div>
                <div class="card-body">
                    <form class="form-horizontal">
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Nama Lengkap</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" value="Ahmad Subagja, S.Pd., M.Pd." readonly>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Email Instansi</label>
                            <div class="col-sm-9">
                                <input type="email" class="form-control" value="ahmad.subagja@siakad.sch.id" readonly>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Nomor Telepon/WA</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" value="081234567890" readonly>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Alamat Domisili</label>
                            <div class="col-sm-9">
                                <textarea class="form-control" rows="3" readonly>Jl. Pendidikan No. 45, Komplek Sekolah, Kab. Semarang</textarea>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\siakad\resources\views/profil.blade.php ENDPATH**/ ?>