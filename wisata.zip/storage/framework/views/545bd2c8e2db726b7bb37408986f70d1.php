

<?php $__env->startSection('title',config('app.name','Laravel')); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Data Mata Pelajaran</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <a href="/mata-pelajaran/tambah" class="btn btn-warning">Tambah</a>
    <a href="/mata-pelajaran/pdf" class="btn btn-secondary">Cetak PDF</a>
    <a href="/mata-pelajaran/excel" class="btn btn-primary">Laporan Excel</a>
    <a href="/mata-pelajaran/csv" class="btn btn-info">Laporan CSV</a>
    <table border="1px" class="table table-bordered" style="width:1000px;">
        <thead>
            <tr>
                <th>Kode Mapel</th>
                <th>Nama Mata Pelajaran</th>
                <th>Kategori</th>
                <th>KKM</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($datas->kode_mapel); ?></td>
                <td><?php echo e($datas->nama_mapel); ?></td>
                <td><?php echo e($datas->kategori); ?></td>
                <td><?php echo e($datas->kkm); ?></td>
                <td>
                    <a href="/mata-pelajaran/ubah/<?php echo e($datas->kode_mapel); ?>">Edit</a>
                    <?php echo method_field('delete'); ?>
                    <a href="/mata-pelajaran/hapus/<?php echo e($datas->kode_mapel); ?>" onclick="return confirm('Anda Yakin Ingin Menghapus data ini ?')">Hapus</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\siakad\resources\views/mata_pelajaran.blade.php ENDPATH**/ ?>