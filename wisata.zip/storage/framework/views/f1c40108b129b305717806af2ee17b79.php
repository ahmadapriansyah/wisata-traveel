

<?php $__env->startSection('title', config('app.name', 'Laravel')); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Data Peserta Wisata</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <a href="/peserta/tambah" class="btn btn-warning">Tambah Peserta</a>
    <a href="/peserta/pdf" class="btn btn-secondary">Cetak PDF</a>
    <a href="/peserta/excel" class="btn btn-primary">Laporan Excel</a>
    <a href="/peserta/csv" class="btn btn-info">Laporan CSV</a>
    <table border="1px" class="table table-bordered mt-3" style="width:1000px;">
        <thead>
            <tr>
                <th>Nama Lengkap</th>
                <th>Jenis Identitas</th>
                <th>No. Identitas</th>
                <th>File Identitas</th>
                <th>No. HP</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
           <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($datas->nama_lengkap ?? '-'); ?></td>
                <td><?php echo e(strtoupper($datas->jenis_identitas ?? '')); ?></td>
                <td><?php echo e($datas->no_identitas ?? '-'); ?></td>
                <td><?php echo e($datas->file_identitas ?? $datas->foto_identitas ?? '-'); ?></td>
                <td><?php echo e($datas->no_hp ?? $datas->kontak ?? '-'); ?></td>
                <td>
                    <a href="/peserta/ubah/<?php echo e($datas->id); ?>" class="btn btn-sm btn-warning">Edit</a>
                    <a href="/peserta/hapus/<?php echo e($datas->id); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Anda yakin ingin menghapus data ini?')">Hapus</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wisata\resources\views/peserta.blade.php ENDPATH**/ ?>