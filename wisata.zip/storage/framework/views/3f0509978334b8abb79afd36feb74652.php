

<?php $__env->startSection('title', config('app.name', 'Laravel')); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Kelas Ajar</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Daftar Kelas Ajar</h3>
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th style="width: 10px">#</th>
                        <th>Nama Kelas</th>
                        <th>Wali Kelas</th>
                        <th>Jumlah Siswa</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>X-IPA 1</td>
                        <td>Drs. Supriyadi</td>
                        <td>32 Siswa</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>XI-IPS 2</td>
                        <td>Siti Aminah, S.Pd.</td>
                        <td>30 Siswa</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>XII-IPA 3</td>
                        <td>Budi Santoso, M.Pd.</td>
                        <td>31 Siswa</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\siakad\resources\views/kelas.blade.php ENDPATH**/ ?>